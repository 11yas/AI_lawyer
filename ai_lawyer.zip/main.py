from fastapi import FastAPI, Request
from fastapi.responses import HTMLResponse
from fastapi.staticfiles import StaticFiles
from fastapi.templating import Jinja2Templates
from pydantic import BaseModel
import requests
import json
import os
import asyncio
from concurrent.futures import ThreadPoolExecutor
import numpy as np
from sklearn.metrics.pairwise import cosine_similarity
from transformers import pipeline

from loader import load_pdfs, embedder
from sentence_transformers import CrossEncoder

# === App and settings ===
app = FastAPI(title="Law RAG Assistant")
executor = ThreadPoolExecutor(max_workers=4)

# === Load vector database ===
collection = load_pdfs("./laws")

# === Stronger reranker ===
reranker = CrossEncoder("cross-encoder/ms-marco-MiniLM-L-6-v2")

# === Question rephraser ===
rephraser = pipeline("text2text-generation", model="google/flan-t5-base")

def clarify_question(user_query: str) -> str:
    """Переформулирует запрос в более точный юридический"""
    try:
        prompt = (
            f"Переформулируй юридический вопрос ясно и официально, "
            f"чтобы он подходил для поиска в законах Казахстана. "
            f"Вопрос: {user_query}"
        )
        result = rephraser(prompt, max_length=64, num_return_sequences=1)[0]['generated_text']
        return result.strip()
    except Exception as e:
        print("⚠ Ошибка reformulation:", e)
        return user_query


# === Query expander ===
def expand_query(q):
    synonyms = {
        # === Преступления и правонарушения ===
        "кража": ["хищение", "воровство", "угон", "незаконное изъятие имущества", "присвоение"],
        "грабеж": ["разбой", "насильственное хищение", "открытое похищение имущества"],
        "убийство": ["лишение жизни", "умышленное причинение смерти", "посягательство на жизнь"],
        "вымогательство": ["шантаж", "принуждение к передаче имущества", "угроза насилием"],
        "взятка": ["подкуп", "незаконное вознаграждение", "коррупция"],
        "мошенничество": ["обман", "незаконное присвоение", "подделка", "фиктивные сделки"],
        "наркотики": ["наркотические вещества", "контрабанда наркотиков", "незаконный оборот наркотиков"],
        "насилие": ["применение силы", "физическое воздействие", "угроза жизни"],

        # === Ответственность и наказание ===
        "наказание": ["ответственность", "санкция", "штраф", "уголовное наказание", "административная мера"],
        "штраф": ["денежное взыскание", "пеня", "административный штраф"],
        "ответственность": ["санкции", "обязанность возместить ущерб", "мера наказания"],

        # === Гражданское право ===
        "договор": ["соглашение", "контракт", "обязательство", "правовой акт"],
        "договор поставки": ["контракт на поставку", "поставка товаров", "коммерческая сделка"],
        "обязательство": ["долг", "договорная обязанность", "выполнение условий"],
        "расторжение": ["аннулирование", "прекращение действия", "отмена договора"],
        "неустойка": ["штрафная санкция", "пеня", "денежное взыскание"],
        "ущерб": ["вред", "потери", "материальный убыток", "компенсация"],

        # === Трудовое право ===
        "увольнение": ["расторжение трудового договора", "прекращение работы", "освобождение от должности"],
        "зарплата": ["заработная плата", "оплата труда", "денежное вознаграждение"],
        "отпуск": ["ежегодный отдых", "отгул", "временное освобождение от работы"],
        "работодатель": ["организация", "фирма", "компания", "наниматель"],
        "работник": ["служащий", "сотрудник", "трудящийся"],

        # === Коммерческое и налоговое право ===
        "налог": ["обязательный платеж", "сбор", "пошлина"],
        "налогоплательщик": ["организация", "гражданин", "предприниматель"],
        "банкротство": ["несостоятельность", "ликвидация компании", "финансовая неплатежеспособность"],
        "компания": ["организация", "фирма", "предприятие", "юридическое лицо"],
        "должник": ["обязанное лицо", "заемщик", "дебитор"],
        "кредитор": ["взыскатель", "лицо, предоставившее заём"],

        # === Административное и процессуальное право ===
        "суд": ["судебный орган", "правосудие", "судья"],
        "закон": ["нормативный акт", "кодекс", "правило", "законодательство"],
        "прокуратура": ["надзорный орган", "государственный обвинитель"],
        "жалоба": ["апелляция", "обращение", "ходатайство"],
        "полиция": ["правоохранительные органы", "служба охраны порядка"],

        # === Бытовые понятия ===
        "магазин": ["торговый объект", "супермаркет", "торговая точка"],
        "имущество": ["вещи", "собственность", "материальные ценности"],
        "деньги": ["наличные", "финансы", "средства"],
        "долг": ["задолженность", "обязательство выплатить", "финансовая обязанность"],
        "обман": ["мошенничество", "ложь", "введение в заблуждение"],
    }
    for word, syns in synonyms.items():
        if word in q:
            q += " " + " ".join(syns)
    return q


# === Static + templates ===
app.mount("/static", StaticFiles(directory="static"), name="static")
templates = Jinja2Templates(directory="templates")


# === Request Model ===
class AskRequest(BaseModel):
    question: str
    model: str = "llama3.1:8b"


# === LLM connector ===
def ask_llm(prompt: str, model: str = "llama3.1:8b") -> str:
    """Отправка запроса в Ollama"""
    try:
        r = requests.post(
            "http://localhost:11434/api/generate",
            json={"model": model, "prompt": prompt, "stream": False},
            timeout=180,
        )
        data = r.json()
        return data.get("response", "нет данных")
    except Exception as e:
        print("⚠ Ошибка при запросе к LLM:", e)
        return "Ошибка: модель не отвечает."


# === Prompt builder ===
def build_prompt(question: str, context: str) -> str:
    return f"""
Ты — опытный юрист по законам Казахстана.

Используй ТОЛЬКО приведённые ниже фрагменты законов.
Если ни один из них прямо не связан с вопросом — напиши «нет данных».

⚖️ Правила:
- Игнорируй статьи, не относящиеся к сути вопроса.
- Не перечисляй случайные статьи только по номеру.
- Не придумывай факты.
- Отвечай строго на русском языке.

📚 Фрагменты закона:
{context}

❓ Вопрос клиента: {question}

💬 Ответ (кратко, по делу):
"""



# === Helper: async embedding ===
async def embed_text_async(text: str):
    loop = asyncio.get_event_loop()
    return await loop.run_in_executor(executor, embedder.encode, text)


# === Main endpoint ===
@app.post("/ask")
async def ask(req: AskRequest):
    # 1️⃣ Расширяем и уточняем запрос
    expanded = expand_query(req.question)
    clarified = clarify_question(expanded)
    print(f"🔍 Reformulated query: {clarified}")

    # 2️⃣ Эмбеддинг уточнённого вопроса
    q_emb = await embed_text_async(clarified)

    # 3️⃣ Поиск по Chroma
    results = collection.query(
        query_embeddings=[q_emb],
        n_results=15,
        include=["documents", "metadatas", "embeddings"]
    )

    docs = results.get("documents", [[]])[0]
    metas = results.get("metadatas", [[]])[0]
    embs = results.get("embeddings", [[]])[0]

    if not docs:
        return {"answer": "нет данных в законе по этому вопросу.", "sources": []}

    # 4️⃣ Фильтрация по косинусному сходству
    similarities = cosine_similarity([q_emb], embs)[0]
    paired = list(zip(docs, metas, similarities))
    paired = sorted(paired, key=lambda x: x[2], reverse=True)
    filtered = [p for p in paired if p[2] > 0.6]
    if not filtered:
        return {"answer": "нет данных в законе по этому вопросу.", "sources": []}

    # 5️⃣ Reranking по смыслу
    rerank_pairs = [(clarified, p[0]) for p in filtered]
    rerank_scores = reranker.predict(rerank_pairs)
    ranked = sorted(zip(filtered, rerank_scores), key=lambda x: x[1], reverse=True)
    ranked = [(d, m, s, r) for (d, m, s), r in ranked if r > 0.4][:5]
    if not ranked:
        return {"answer": "нет данных в законе по этому вопросу.", "sources": []}


    # 6️⃣ Формируем контекст
    context_parts = []
    for (doc, meta, score), rscore in ranked:
        snippet = doc.strip().replace("\n", " ")
        context_parts.append(
            f"[{meta.get('source', 'неизвестно')} | sim={score:.2f}, rank={rscore:.2f}]: {snippet[:800]}..."
        )
    context = "\n\n".join(context_parts)

    # 7️⃣ Формируем промпт и спрашиваем LLM
    prompt = build_prompt(clarified, context)
    answer = ask_llm(prompt, req.model)

    return {
        "answer": answer,
        "sources": [meta for (_, meta, _), _ in ranked],
        "clarified": clarified,
        "context_used": len(context_parts),
    }


# === Web UI ===
@app.get("/", response_class=HTMLResponse)
def chat_ui(request: Request):
    return templates.TemplateResponse("index.html", {"request": request})


@app.get("/health")
def health():
    return {"status": "ok"}
